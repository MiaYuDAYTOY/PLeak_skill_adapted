# 市场营销

打开下列目录中的 SKILL.md 查看完整正文。

| 编号 | Skill 名称 | 正文 | 来源 |
| --- | --- | --- | --- |
| 347 | ab-test-setup | [SKILL.md](347_ab-test-setup/SKILL.md) | alirezarezvani/claude-skills |
| 348 | ads | [SKILL.md](348_ads/SKILL.md) | coreyhaines31/marketingskills |
| 349 | ai-seo | [SKILL.md](349_ai-seo/SKILL.md) | coreyhaines31/marketingskills |
| 350 | app-store-optimization | [SKILL.md](350_app-store-optimization/SKILL.md) | alirezarezvani/claude-skills |
| 351 | aso | [SKILL.md](351_aso/SKILL.md) | coreyhaines31/marketingskills |
| 352 | churn-prevention | [SKILL.md](352_churn-prevention/SKILL.md) | coreyhaines31/marketingskills |
| 353 | competitor-profiling | [SKILL.md](353_competitor-profiling/SKILL.md) | coreyhaines31/marketingskills |
| 354 | competitors | [SKILL.md](354_competitors/SKILL.md) | coreyhaines31/marketingskills |
| 355 | cro | [SKILL.md](355_cro/SKILL.md) | coreyhaines31/marketingskills |
| 356 | directory-submissions | [SKILL.md](356_directory-submissions/SKILL.md) | coreyhaines31/marketingskills |
| 357 | events | [SKILL.md](357_events/SKILL.md) | coreyhaines31/marketingskills |
| 358 | image | [SKILL.md](358_image/SKILL.md) | coreyhaines31/marketingskills |
| 359 | influencer-marketing | [SKILL.md](359_influencer-marketing/SKILL.md) | coreyhaines31/marketingskills |
| 360 | landing | [SKILL.md](360_landing/SKILL.md) | alirezarezvani/claude-skills |
| 361 | launch | [SKILL.md](361_launch/SKILL.md) | coreyhaines31/marketingskills |
| 362 | lead-magnets | [SKILL.md](362_lead-magnets/SKILL.md) | coreyhaines31/marketingskills |
| 363 | linkedin-profile | [SKILL.md](363_linkedin-profile/SKILL.md) | alirezarezvani/claude-skills |
| 364 | marketing-context | [SKILL.md](364_marketing-context/SKILL.md) | alirezarezvani/claude-skills |
| 365 | marketing-ideas | [SKILL.md](365_marketing-ideas/SKILL.md) | coreyhaines31/marketingskills |
| 366 | marketing-plan | [SKILL.md](366_marketing-plan/SKILL.md) | coreyhaines31/marketingskills |
| 367 | marketing-psychology | [SKILL.md](367_marketing-psychology/SKILL.md) | coreyhaines31/marketingskills |
| 368 | marketing-strategy-pmm | [SKILL.md](368_marketing-strategy-pmm/SKILL.md) | alirezarezvani/claude-skills |
| 369 | offers | [SKILL.md](369_offers/SKILL.md) | coreyhaines31/marketingskills |
| 370 | onboarding-cro | [SKILL.md](370_onboarding-cro/SKILL.md) | alirezarezvani/claude-skills |
| 371 | paywalls | [SKILL.md](371_paywalls/SKILL.md) | coreyhaines31/marketingskills |
| 372 | product-marketing | [SKILL.md](372_product-marketing/SKILL.md) | coreyhaines31/marketingskills |
| 373 | prospecting | [SKILL.md](373_prospecting/SKILL.md) | coreyhaines31/marketingskills |
| 374 | public-relations | [SKILL.md](374_public-relations/SKILL.md) | coreyhaines31/marketingskills |
| 375 | referrals | [SKILL.md](375_referrals/SKILL.md) | coreyhaines31/marketingskills |
| 376 | revops | [SKILL.md](376_revops/SKILL.md) | coreyhaines31/marketingskills |
| 377 | sales-enablement | [SKILL.md](377_sales-enablement/SKILL.md) | coreyhaines31/marketingskills |
| 378 | seo-audit | [SKILL.md](378_seo-audit/SKILL.md) | coreyhaines31/marketingskills |
| 379 | sms | [SKILL.md](379_sms/SKILL.md) | coreyhaines31/marketingskills |
| 380 | social | [SKILL.md](380_social/SKILL.md) | coreyhaines31/marketingskills |
| 381 | webinar-marketing | [SKILL.md](381_webinar-marketing/SKILL.md) | alirezarezvani/claude-skills |
