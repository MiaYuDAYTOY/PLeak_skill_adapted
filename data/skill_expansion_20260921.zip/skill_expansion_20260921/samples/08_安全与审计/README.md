# 安全与审计

打开下列目录中的 SKILL.md 查看完整正文。

| 编号 | Skill 名称 | 正文 | 来源 |
| --- | --- | --- | --- |
| 275 | aflpp | [SKILL.md](275_aflpp/SKILL.md) | trailofbits/skills |
| 276 | agentic-actions-auditor | [SKILL.md](276_agentic-actions-auditor/SKILL.md) | trailofbits/skills |
| 277 | algorand-vulnerability-scanner | [SKILL.md](277_algorand-vulnerability-scanner/SKILL.md) | trailofbits/skills |
| 278 | audit-integrity | [SKILL.md](278_audit-integrity/SKILL.md) | github/awesome-copilot |
| 279 | burpsuite-project-parser | [SKILL.md](279_burpsuite-project-parser/SKILL.md) | trailofbits/skills |
| 280 | claude-settings-audit | [SKILL.md](280_claude-settings-audit/SKILL.md) | getsentry/skills |
| 281 | code-maturity-assessor | [SKILL.md](281_code-maturity-assessor/SKILL.md) | trailofbits/skills |
| 282 | codeql | [SKILL.md](282_codeql/SKILL.md) | trailofbits/skills |
| 283 | constant-time-testing | [SKILL.md](283_constant-time-testing/SKILL.md) | trailofbits/skills |
| 284 | dimensional-analysis | [SKILL.md](284_dimensional-analysis/SKILL.md) | trailofbits/skills |
| 285 | fuzzing-obstacles | [SKILL.md](285_fuzzing-obstacles/SKILL.md) | trailofbits/skills |
| 286 | gha-security-review | [SKILL.md](286_gha-security-review/SKILL.md) | getsentry/skills |
| 287 | github-triage | [SKILL.md](287_github-triage/SKILL.md) | trailofbits/skills |
| 288 | harness-writing | [SKILL.md](288_harness-writing/SKILL.md) | trailofbits/skills |
| 289 | libfuzzer | [SKILL.md](289_libfuzzer/SKILL.md) | trailofbits/skills |
| 290 | mcp-security-audit | [SKILL.md](290_mcp-security-audit/SKILL.md) | github/awesome-copilot |
| 291 | mermaid-to-proverif | [SKILL.md](291_mermaid-to-proverif/SKILL.md) | trailofbits/skills |
| 292 | ossfuzz | [SKILL.md](292_ossfuzz/SKILL.md) | trailofbits/skills |
| 293 | react-audit-grep-patterns | [SKILL.md](293_react-audit-grep-patterns/SKILL.md) | github/awesome-copilot |
| 294 | sarif-parsing | [SKILL.md](294_sarif-parsing/SKILL.md) | trailofbits/skills |
| 295 | security-best-practices | [SKILL.md](295_security-best-practices/SKILL.md) | openai/skills |
| 296 | security-guidance | [SKILL.md](296_security-guidance/SKILL.md) | alirezarezvani/claude-skills |
| 297 | security-ownership-map | [SKILL.md](297_security-ownership-map/SKILL.md) | openai/skills |
| 298 | security-review | [SKILL.md](298_security-review/SKILL.md) | getsentry/skills |
| 299 | security-threat-model | [SKILL.md](299_security-threat-model/SKILL.md) | openai/skills |
| 300 | threat-mitigation-mapping | [SKILL.md](300_threat-mitigation-mapping/SKILL.md) | wshobson/agents |
| 301 | ton-vulnerability-scanner | [SKILL.md](301_ton-vulnerability-scanner/SKILL.md) | trailofbits/skills |
| 302 | trailmark | [SKILL.md](302_trailmark/SKILL.md) | trailofbits/skills |
| 303 | trailmark-review-gate | [SKILL.md](303_trailmark-review-gate/SKILL.md) | trailofbits/skills |
| 304 | trailmark-summary | [SKILL.md](304_trailmark-summary/SKILL.md) | trailofbits/skills |
| 305 | trailmark-variant-neighborhood | [SKILL.md](305_trailmark-variant-neighborhood/SKILL.md) | trailofbits/skills |
| 306 | variant-analysis | [SKILL.md](306_variant-analysis/SKILL.md) | trailofbits/skills |
| 307 | vector-forge | [SKILL.md](307_vector-forge/SKILL.md) | trailofbits/skills |
| 308 | writing-lean-proofs | [SKILL.md](308_writing-lean-proofs/SKILL.md) | trailofbits/skills |
| 309 | wycheproof | [SKILL.md](309_wycheproof/SKILL.md) | trailofbits/skills |
| 310 | yara-rule-authoring | [SKILL.md](310_yara-rule-authoring/SKILL.md) | trailofbits/skills |
| 311 | zeroize-audit | [SKILL.md](311_zeroize-audit/SKILL.md) | trailofbits/skills |
