# 云服务与部署

打开下列目录中的 SKILL.md 查看完整正文。

| 编号 | Skill 名称 | 正文 | 来源 |
| --- | --- | --- | --- |
| 312 | agents-sdk | [SKILL.md](312_agents-sdk/SKILL.md) | cloudflare/skills |
| 313 | applicationinsights-web-ts | [SKILL.md](313_applicationinsights-web-ts/SKILL.md) | microsoft/skills |
| 314 | azure-ai | [SKILL.md](314_azure-ai/SKILL.md) | microsoft/skills |
| 315 | azure-cloud-migrate | [SKILL.md](315_azure-cloud-migrate/SKILL.md) | microsoft/skills |
| 316 | azure-communication-callingserver-java | [SKILL.md](316_azure-communication-callingserver-java/SKILL.md) | microsoft/skills |
| 317 | azure-identity-py | [SKILL.md](317_azure-identity-py/SKILL.md) | microsoft/skills |
| 318 | azure-kubernetes-app-deploy | [SKILL.md](318_azure-kubernetes-app-deploy/SKILL.md) | microsoft/skills |
| 319 | azure-kusto-irql-graph | [SKILL.md](319_azure-kusto-irql-graph/SKILL.md) | microsoft/skills |
| 320 | azure-messaging-webpubsubservice-py | [SKILL.md](320_azure-messaging-webpubsubservice-py/SKILL.md) | microsoft/skills |
| 321 | azure-resource-manager-postgresql-dotnet | [SKILL.md](321_azure-resource-manager-postgresql-dotnet/SKILL.md) | microsoft/skills |
| 322 | cloudflare | [SKILL.md](322_cloudflare/SKILL.md) | cloudflare/skills |
| 323 | cloudflare-email-service | [SKILL.md](323_cloudflare-email-service/SKILL.md) | cloudflare/skills |
| 324 | cloudflare-one | [SKILL.md](324_cloudflare-one/SKILL.md) | cloudflare/skills |
| 325 | cloudflare-one-migrations | [SKILL.md](325_cloudflare-one-migrations/SKILL.md) | cloudflare/skills |
| 326 | durable-objects | [SKILL.md](326_durable-objects/SKILL.md) | cloudflare/skills |
| 327 | entra-agent-id | [SKILL.md](327_entra-agent-id/SKILL.md) | microsoft/skills |
| 328 | fastapi-router-py | [SKILL.md](328_fastapi-router-py/SKILL.md) | microsoft/skills |
| 329 | hf-cloud-aws-context-discovery | [SKILL.md](329_hf-cloud-aws-context-discovery/SKILL.md) | huggingface/skills |
| 330 | hf-cloud-python-env-setup | [SKILL.md](330_hf-cloud-python-env-setup/SKILL.md) | huggingface/skills |
| 331 | hf-cloud-sagemaker-deployment-planner | [SKILL.md](331_hf-cloud-sagemaker-deployment-planner/SKILL.md) | huggingface/skills |
| 332 | hf-cloud-sagemaker-iam-preflight | [SKILL.md](332_hf-cloud-sagemaker-iam-preflight/SKILL.md) | huggingface/skills |
| 333 | hf-cloud-sagemaker-production-defaults | [SKILL.md](333_hf-cloud-sagemaker-production-defaults/SKILL.md) | huggingface/skills |
| 334 | hf-cloud-serving-image-selection | [SKILL.md](334_hf-cloud-serving-image-selection/SKILL.md) | huggingface/skills |
| 335 | microsoft-azure-webjobs-extensions-authentication-events-dotnet | [SKILL.md](335_microsoft-azure-webjobs-extensions-authentication-events-dotnet/SKILL.md) | microsoft/skills |
| 336 | microsoft-foundry | [SKILL.md](336_microsoft-foundry/SKILL.md) | microsoft/skills |
| 337 | nextjs-on-cloudflare | [SKILL.md](337_nextjs-on-cloudflare/SKILL.md) | cloudflare/skills |
| 338 | pydantic-models-py | [SKILL.md](338_pydantic-models-py/SKILL.md) | microsoft/skills |
| 339 | python-appservice-deploy | [SKILL.md](339_python-appservice-deploy/SKILL.md) | microsoft/skills |
| 340 | sandbox-migrate-to-next | [SKILL.md](340_sandbox-migrate-to-next/SKILL.md) | cloudflare/skills |
| 341 | sandbox-stable | [SKILL.md](341_sandbox-stable/SKILL.md) | cloudflare/skills |
| 342 | turnstile-spin | [SKILL.md](342_turnstile-spin/SKILL.md) | cloudflare/skills |
| 343 | web-perf | [SKILL.md](343_web-perf/SKILL.md) | cloudflare/skills |
| 344 | workers-best-practices | [SKILL.md](344_workers-best-practices/SKILL.md) | cloudflare/skills |
| 345 | wrangler | [SKILL.md](345_wrangler/SKILL.md) | cloudflare/skills |
| 346 | zustand-store-ts | [SKILL.md](346_zustand-store-ts/SKILL.md) | microsoft/skills |
