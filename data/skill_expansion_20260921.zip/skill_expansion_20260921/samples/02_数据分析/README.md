# 数据分析

打开下列目录中的 SKILL.md 查看完整正文。

| 编号 | Skill 名称 | 正文 | 来源 |
| --- | --- | --- | --- |
| 017 | analytics | [SKILL.md](017_analytics/SKILL.md) | coreyhaines31/marketingskills |
| 018 | analytics-tracking | [SKILL.md](018_analytics-tracking/SKILL.md) | alirezarezvani/claude-skills |
| 019 | arize-dataset | [SKILL.md](019_arize-dataset/SKILL.md) | github/awesome-copilot |
| 020 | attribution | [SKILL.md](020_attribution/SKILL.md) | coreyhaines31/marketingskills |
| 021 | database-migration | [SKILL.md](021_database-migration/SKILL.md) | wshobson/agents |
| 022 | dataset-curation | [SKILL.md](022_dataset-curation/SKILL.md) | wshobson/agents |
| 023 | grpo-rlvr-training | [SKILL.md](023_grpo-rlvr-training/SKILL.md) | wshobson/agents |
| 024 | hf-cli | [SKILL.md](024_hf-cli/SKILL.md) | huggingface/skills |
| 025 | hf-mem | [SKILL.md](025_hf-mem/SKILL.md) | huggingface/skills |
| 026 | huggingface-best | [SKILL.md](026_huggingface-best/SKILL.md) | huggingface/skills |
| 027 | huggingface-community-evals | [SKILL.md](027_huggingface-community-evals/SKILL.md) | huggingface/skills |
| 028 | huggingface-datasets | [SKILL.md](028_huggingface-datasets/SKILL.md) | huggingface/skills |
| 029 | huggingface-gradio | [SKILL.md](029_huggingface-gradio/SKILL.md) | huggingface/skills |
| 030 | huggingface-llm-trainer | [SKILL.md](030_huggingface-llm-trainer/SKILL.md) | huggingface/skills |
| 031 | huggingface-local-models | [SKILL.md](031_huggingface-local-models/SKILL.md) | huggingface/skills |
| 032 | huggingface-lora-space-builder | [SKILL.md](032_huggingface-lora-space-builder/SKILL.md) | huggingface/skills |
| 033 | huggingface-paper-publisher | [SKILL.md](033_huggingface-paper-publisher/SKILL.md) | huggingface/skills |
| 034 | huggingface-spaces | [SKILL.md](034_huggingface-spaces/SKILL.md) | huggingface/skills |
| 035 | huggingface-tool-builder | [SKILL.md](035_huggingface-tool-builder/SKILL.md) | huggingface/skills |
| 036 | huggingface-trackio | [SKILL.md](036_huggingface-trackio/SKILL.md) | huggingface/skills |
| 037 | huggingface-vision-trainer | [SKILL.md](037_huggingface-vision-trainer/SKILL.md) | huggingface/skills |
| 038 | huggingface-zerogpu | [SKILL.md](038_huggingface-zerogpu/SKILL.md) | huggingface/skills |
| 039 | jupyter-notebook | [SKILL.md](039_jupyter-notebook/SKILL.md) | openai/skills |
| 040 | spark-training-gotchas | [SKILL.md](040_spark-training-gotchas/SKILL.md) | wshobson/agents |
| 041 | sql-code-review | [SKILL.md](041_sql-code-review/SKILL.md) | github/awesome-copilot |
| 042 | sql-object-impact-analysis | [SKILL.md](042_sql-object-impact-analysis/SKILL.md) | github/awesome-copilot |
| 043 | sql-optimization | [SKILL.md](043_sql-optimization/SKILL.md) | github/awesome-copilot |
| 044 | sql-optimization-patterns | [SKILL.md](044_sql-optimization-patterns/SKILL.md) | wshobson/agents |
| 045 | sql-queries | [SKILL.md](045_sql-queries/SKILL.md) | phuryn/pm-skills |
| 046 | sql-server-table-reconciliation | [SKILL.md](046_sql-server-table-reconciliation/SKILL.md) | github/awesome-copilot |
| 047 | supabase | [SKILL.md](047_supabase/SKILL.md) | supabase/agent-skills |
| 048 | trace-to-training-data | [SKILL.md](048_trace-to-training-data/SKILL.md) | wshobson/agents |
| 049 | train-sentence-transformers | [SKILL.md](049_train-sentence-transformers/SKILL.md) | huggingface/skills |
| 050 | transformers-js | [SKILL.md](050_transformers-js/SKILL.md) | huggingface/skills |
| 051 | trl-training | [SKILL.md](051_trl-training/SKILL.md) | huggingface/skills |
