# 工作流与协作

打开下列目录中的 SKILL.md 查看完整正文。

| 编号 | Skill 名称 | 正文 | 来源 |
| --- | --- | --- | --- |
| 177 | agent-email-inbox | [SKILL.md](177_agent-email-inbox/SKILL.md) | resend/resend-skills |
| 178 | billing-automation | [SKILL.md](178_billing-automation/SKILL.md) | wshobson/agents |
| 179 | cloudflare-deploy | [SKILL.md](179_cloudflare-deploy/SKILL.md) | openai/skills |
| 180 | commit | [SKILL.md](180_commit/SKILL.md) | getsentry/skills |
| 181 | create-github-issues-feature-from-implementation-plan | [SKILL.md](181_create-github-issues-feature-from-implementation-plan/SKILL.md) | github/awesome-copilot |
| 182 | debian-linux-triage | [SKILL.md](182_debian-linux-triage/SKILL.md) | github/awesome-copilot |
| 183 | define-goal | [SKILL.md](183_define-goal/SKILL.md) | openai/skills |
| 184 | discernment-nudge | [SKILL.md](184_discernment-nudge/SKILL.md) | anthropics/skills |
| 185 | expo-project-structure | [SKILL.md](185_expo-project-structure/SKILL.md) | expo/skills |
| 186 | gh-address-comments | [SKILL.md](186_gh-address-comments/SKILL.md) | openai/skills |
| 187 | gh-cli | [SKILL.md](187_gh-cli/SKILL.md) | trailofbits/skills |
| 188 | gh-fix-ci | [SKILL.md](188_gh-fix-ci/SKILL.md) | openai/skills |
| 189 | imagegen | [SKILL.md](189_imagegen/SKILL.md) | openai/skills |
| 190 | internal-comms | [SKILL.md](190_internal-comms/SKILL.md) | anthropics/skills |
| 191 | interpreting-culture-index | [SKILL.md](191_interpreting-culture-index/SKILL.md) | trailofbits/skills |
| 192 | linear | [SKILL.md](192_linear/SKILL.md) | openai/skills |
| 193 | netlify-deploy | [SKILL.md](193_netlify-deploy/SKILL.md) | openai/skills |
| 194 | notion-knowledge-capture | [SKILL.md](194_notion-knowledge-capture/SKILL.md) | openai/skills |
| 195 | notion-meeting-intelligence | [SKILL.md](195_notion-meeting-intelligence/SKILL.md) | openai/skills |
| 196 | notion-research-documentation | [SKILL.md](196_notion-research-documentation/SKILL.md) | openai/skills |
| 197 | notion-spec-to-implementation | [SKILL.md](197_notion-spec-to-implementation/SKILL.md) | openai/skills |
| 198 | playwright-automation-fill-in-form | [SKILL.md](198_playwright-automation-fill-in-form/SKILL.md) | github/awesome-copilot |
| 199 | plugin-creator | [SKILL.md](199_plugin-creator/SKILL.md) | openai/skills |
| 200 | pr-link-issue | [SKILL.md](200_pr-link-issue/SKILL.md) | getsentry/skills |
| 201 | react-email | [SKILL.md](201_react-email/SKILL.md) | resend/resend-skills |
| 202 | render-deploy | [SKILL.md](202_render-deploy/SKILL.md) | openai/skills |
| 203 | resend | [SKILL.md](203_resend/SKILL.md) | resend/resend-skills |
| 204 | resend-cli | [SKILL.md](204_resend-cli/SKILL.md) | resend/resend-skills |
| 205 | sentry | [SKILL.md](205_sentry/SKILL.md) | openai/skills |
| 206 | skill-installer | [SKILL.md](206_skill-installer/SKILL.md) | openai/skills |
| 207 | sred-project-organizer | [SKILL.md](207_sred-project-organizer/SKILL.md) | getsentry/skills |
| 208 | transcribe | [SKILL.md](208_transcribe/SKILL.md) | openai/skills |
| 209 | triage-frontend-issues | [SKILL.md](209_triage-frontend-issues/SKILL.md) | getsentry/skills |
| 210 | vercel-deploy | [SKILL.md](210_vercel-deploy/SKILL.md) | openai/skills |
| 211 | winui-app | [SKILL.md](211_winui-app/SKILL.md) | openai/skills |
| 212 | workflow-patterns | [SKILL.md](212_workflow-patterns/SKILL.md) | wshobson/agents |
| 213 | yeet | [SKILL.md](213_yeet/SKILL.md) | openai/skills |
