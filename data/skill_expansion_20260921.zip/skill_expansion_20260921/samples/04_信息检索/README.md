# 信息检索

打开下列目录中的 SKILL.md 查看完整正文。

| 编号 | Skill 名称 | 正文 | 来源 |
| --- | --- | --- | --- |
| 143 | academy-guide | [SKILL.md](143_academy-guide/SKILL.md) | anthropics/skills |
| 144 | azure-maps-search-dotnet | [SKILL.md](144_azure-maps-search-dotnet/SKILL.md) | microsoft/skills |
| 145 | azure-search-documents-py | [SKILL.md](145_azure-search-documents-py/SKILL.md) | microsoft/skills |
| 146 | bgpt-paper-search | [SKILL.md](146_bgpt-paper-search/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 147 | browser-automation | [SKILL.md](147_browser-automation/SKILL.md) | alirezarezvani/claude-skills |
| 148 | dossier | [SKILL.md](148_dossier/SKILL.md) | alirezarezvani/claude-skills |
| 149 | hf-mcp | [SKILL.md](149_hf-mcp/SKILL.md) | huggingface/skills |
| 150 | huggingface-papers | [SKILL.md](150_huggingface-papers/SKILL.md) | huggingface/skills |
| 151 | hybrid-search-implementation | [SKILL.md](151_hybrid-search-implementation/SKILL.md) | wshobson/agents |
| 152 | litreview | [SKILL.md](152_litreview/SKILL.md) | alirezarezvani/claude-skills |
| 153 | notebooklm | [SKILL.md](153_notebooklm/SKILL.md) | alirezarezvani/claude-skills |
| 154 | openai-docs | [SKILL.md](154_openai-docs/SKILL.md) | openai/skills |
| 155 | patent | [SKILL.md](155_patent/SKILL.md) | alirezarezvani/claude-skills |
| 156 | product-research | [SKILL.md](156_product-research/SKILL.md) | alirezarezvani/claude-skills |
| 157 | pulse | [SKILL.md](157_pulse/SKILL.md) | alirezarezvani/claude-skills |
| 158 | qdrant-search-quality | [SKILL.md](158_qdrant-search-quality/SKILL.md) | github/awesome-copilot |
| 159 | qdrant-search-quality-diagnosis | [SKILL.md](159_qdrant-search-quality-diagnosis/SKILL.md) | github/awesome-copilot |
| 160 | qdrant-search-speed-optimization | [SKILL.md](160_qdrant-search-speed-optimization/SKILL.md) | github/awesome-copilot |
| 161 | qdrant-search-strategies | [SKILL.md](161_qdrant-search-strategies/SKILL.md) | github/awesome-copilot |
| 162 | research | [SKILL.md](162_research/SKILL.md) | alirezarezvani/claude-skills |
| 163 | similarity-search-patterns | [SKILL.md](163_similarity-search-patterns/SKILL.md) | wshobson/agents |
| 164 | syllabus | [SKILL.md](164_syllabus/SKILL.md) | alirezarezvani/claude-skills |
| 165 | technical-job-search | [SKILL.md](165_technical-job-search/SKILL.md) | github/awesome-copilot |
| 166 | universal-scraping-architect | [SKILL.md](166_universal-scraping-architect/SKILL.md) | alirezarezvani/claude-skills |
| 167 | wiki-ado-convert | [SKILL.md](167_wiki-ado-convert/SKILL.md) | microsoft/skills |
| 168 | wiki-agents-md | [SKILL.md](168_wiki-agents-md/SKILL.md) | microsoft/skills |
| 169 | wiki-architect | [SKILL.md](169_wiki-architect/SKILL.md) | microsoft/skills |
| 170 | wiki-changelog | [SKILL.md](170_wiki-changelog/SKILL.md) | microsoft/skills |
| 171 | wiki-onboarding | [SKILL.md](171_wiki-onboarding/SKILL.md) | microsoft/skills |
| 172 | wiki-page-writer | [SKILL.md](172_wiki-page-writer/SKILL.md) | microsoft/skills |
| 173 | wiki-qa | [SKILL.md](173_wiki-qa/SKILL.md) | microsoft/skills |
| 174 | wiki-researcher | [SKILL.md](174_wiki-researcher/SKILL.md) | microsoft/skills |
| 175 | wiki-vitepress | [SKILL.md](175_wiki-vitepress/SKILL.md) | microsoft/skills |
| 176 | winmd-api-search | [SKILL.md](176_winmd-api-search/SKILL.md) | github/awesome-copilot |
