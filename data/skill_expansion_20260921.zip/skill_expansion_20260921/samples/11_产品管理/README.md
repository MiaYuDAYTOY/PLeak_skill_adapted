# 产品管理

打开下列目录中的 SKILL.md 查看完整正文。

| 编号 | Skill 名称 | 正文 | 来源 |
| --- | --- | --- | --- |
| 382 | ansoff-matrix | [SKILL.md](382_ansoff-matrix/SKILL.md) | phuryn/pm-skills |
| 383 | brainstorm-experiments-new | [SKILL.md](383_brainstorm-experiments-new/SKILL.md) | phuryn/pm-skills |
| 384 | brainstorm-ideas-new | [SKILL.md](384_brainstorm-ideas-new/SKILL.md) | phuryn/pm-skills |
| 385 | code-to-prd | [SKILL.md](385_code-to-prd/SKILL.md) | alirezarezvani/claude-skills |
| 386 | competitive-battlecard | [SKILL.md](386_competitive-battlecard/SKILL.md) | phuryn/pm-skills |
| 387 | competitor-analysis | [SKILL.md](387_competitor-analysis/SKILL.md) | phuryn/pm-skills |
| 388 | create-prd | [SKILL.md](388_create-prd/SKILL.md) | phuryn/pm-skills |
| 389 | customer-journey-map | [SKILL.md](389_customer-journey-map/SKILL.md) | phuryn/pm-skills |
| 390 | experiment-designer | [SKILL.md](390_experiment-designer/SKILL.md) | alirezarezvani/claude-skills |
| 391 | gtm-strategy | [SKILL.md](391_gtm-strategy/SKILL.md) | phuryn/pm-skills |
| 392 | identify-assumptions-existing | [SKILL.md](392_identify-assumptions-existing/SKILL.md) | phuryn/pm-skills |
| 393 | interview-script | [SKILL.md](393_interview-script/SKILL.md) | phuryn/pm-skills |
| 394 | lean-canvas | [SKILL.md](394_lean-canvas/SKILL.md) | phuryn/pm-skills |
| 395 | north-star-metric | [SKILL.md](395_north-star-metric/SKILL.md) | phuryn/pm-skills |
| 396 | opportunity-solution-tree | [SKILL.md](396_opportunity-solution-tree/SKILL.md) | phuryn/pm-skills |
| 397 | pre-mortem | [SKILL.md](397_pre-mortem/SKILL.md) | phuryn/pm-skills |
| 398 | prioritize-features | [SKILL.md](398_prioritize-features/SKILL.md) | phuryn/pm-skills |
| 399 | product-discovery | [SKILL.md](399_product-discovery/SKILL.md) | alirezarezvani/claude-skills |
| 400 | product-manager-toolkit | [SKILL.md](400_product-manager-toolkit/SKILL.md) | alirezarezvani/claude-skills |
| 401 | product-name | [SKILL.md](401_product-name/SKILL.md) | phuryn/pm-skills |
| 402 | research-summarizer | [SKILL.md](402_research-summarizer/SKILL.md) | alirezarezvani/claude-skills |
| 403 | retro | [SKILL.md](403_retro/SKILL.md) | phuryn/pm-skills |
| 404 | roadmap-communicator | [SKILL.md](404_roadmap-communicator/SKILL.md) | alirezarezvani/claude-skills |
| 405 | sentiment-analysis | [SKILL.md](405_sentiment-analysis/SKILL.md) | phuryn/pm-skills |
| 406 | stakeholder-map | [SKILL.md](406_stakeholder-map/SKILL.md) | phuryn/pm-skills |
| 407 | strategy-red-team | [SKILL.md](407_strategy-red-team/SKILL.md) | phuryn/pm-skills |
| 408 | summarize-interview | [SKILL.md](408_summarize-interview/SKILL.md) | phuryn/pm-skills |
| 409 | summarize-meeting | [SKILL.md](409_summarize-meeting/SKILL.md) | phuryn/pm-skills |
| 410 | swot-analysis | [SKILL.md](410_swot-analysis/SKILL.md) | phuryn/pm-skills |
| 411 | test-scenarios | [SKILL.md](411_test-scenarios/SKILL.md) | phuryn/pm-skills |
| 412 | user-personas | [SKILL.md](412_user-personas/SKILL.md) | phuryn/pm-skills |
| 413 | user-stories | [SKILL.md](413_user-stories/SKILL.md) | phuryn/pm-skills |
| 414 | value-prop-statements | [SKILL.md](414_value-prop-statements/SKILL.md) | phuryn/pm-skills |
| 415 | wwas | [SKILL.md](415_wwas/SKILL.md) | phuryn/pm-skills |
