# 科学研究

打开下列目录中的 SKILL.md 查看完整正文。

| 编号 | Skill 名称 | 正文 | 来源 |
| --- | --- | --- | --- |
| 250 | alphagenome | [SKILL.md](250_alphagenome/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 251 | analytical-method-validation | [SKILL.md](251_analytical-method-validation/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 252 | autoskill | [SKILL.md](252_autoskill/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 253 | bids | [SKILL.md](253_bids/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 254 | biopython | [SKILL.md](254_biopython/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 255 | bulk-rnaseq | [SKILL.md](255_bulk-rnaseq/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 256 | deeptools | [SKILL.md](256_deeptools/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 257 | diffdock | [SKILL.md](257_diffdock/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 258 | genomic-intelligence | [SKILL.md](258_genomic-intelligence/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 259 | hypothesis-generation | [SKILL.md](259_hypothesis-generation/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 260 | iso-standards-readiness | [SKILL.md](260_iso-standards-readiness/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 261 | lab-hardware-cad | [SKILL.md](261_lab-hardware-cad/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 262 | matlab | [SKILL.md](262_matlab/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 263 | networkx | [SKILL.md](263_networkx/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 264 | neuropixels-analysis | [SKILL.md](264_neuropixels-analysis/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 265 | onekgpd | [SKILL.md](265_onekgpd/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 266 | paperclip | [SKILL.md](266_paperclip/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 267 | pkpd-modeling | [SKILL.md](267_pkpd-modeling/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 268 | pydicom | [SKILL.md](268_pydicom/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 269 | pymatgen | [SKILL.md](269_pymatgen/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 270 | relsa-severity-assessment | [SKILL.md](270_relsa-severity-assessment/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 271 | tamarind | [SKILL.md](271_tamarind/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 272 | torch-geometric | [SKILL.md](272_torch-geometric/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 273 | uncertainty-and-units | [SKILL.md](273_uncertainty-and-units/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 274 | vaex | [SKILL.md](274_vaex/SKILL.md) | K-Dense-AI/scientific-agent-skills |
