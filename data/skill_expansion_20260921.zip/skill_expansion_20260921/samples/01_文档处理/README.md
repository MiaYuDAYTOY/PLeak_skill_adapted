# 文档处理

打开下列目录中的 SKILL.md 查看完整正文。

| 编号 | Skill 名称 | 正文 | 来源 |
| --- | --- | --- | --- |
| 001 | azure-ai-document-intelligence-dotnet | [SKILL.md](001_azure-ai-document-intelligence-dotnet/SKILL.md) | microsoft/skills |
| 002 | azure-ai-translation-document-py | [SKILL.md](002_azure-ai-translation-document-py/SKILL.md) | microsoft/skills |
| 003 | convert-pdf-to-md | [SKILL.md](003_convert-pdf-to-md/SKILL.md) | github/awesome-copilot |
| 004 | document-api-endpoint | [SKILL.md](004_document-api-endpoint/SKILL.md) | getsentry/skills |
| 005 | latex-posters | [SKILL.md](005_latex-posters/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 006 | md-document | [SKILL.md](006_md-document/SKILL.md) | alirezarezvani/claude-skills |
| 007 | md-slides | [SKILL.md](007_md-slides/SKILL.md) | alirezarezvani/claude-skills |
| 008 | md-to-docx | [SKILL.md](008_md-to-docx/SKILL.md) | github/awesome-copilot |
| 009 | pptx-deck-context | [SKILL.md](009_pptx-deck-context/SKILL.md) | wshobson/agents |
| 010 | pptx-posters | [SKILL.md](010_pptx-posters/SKILL.md) | K-Dense-AI/scientific-agent-skills |
| 011 | pptx-quality-gates | [SKILL.md](011_pptx-quality-gates/SKILL.md) | wshobson/agents |
| 012 | pptx-reference-deck-analysis | [SKILL.md](012_pptx-reference-deck-analysis/SKILL.md) | wshobson/agents |
| 013 | pptx-slide-specification | [SKILL.md](013_pptx-slide-specification/SKILL.md) | wshobson/agents |
| 014 | pptx-visual-assets | [SKILL.md](014_pptx-visual-assets/SKILL.md) | wshobson/agents |
| 015 | presentation-creator | [SKILL.md](015_presentation-creator/SKILL.md) | getsentry/skills |
| 016 | scientific-slides | [SKILL.md](016_scientific-slides/SKILL.md) | K-Dense-AI/scientific-agent-skills |
