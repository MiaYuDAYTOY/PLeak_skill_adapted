# 公开 Skill 数据集扩充与核查报告

## 如何直接查看 Skill 正文

新增正文已按 `samples/功能类别/编号_名称/SKILL.md` 整理。完整分类导航见 [README.md](README.md)。清单 local_path 已同步更新，稳定 sample_id 和正文哈希保持不变。

采集日期：2026-09-21；每条实际 UTC 时间见 `retrieved_at`。本轮仅检索、采集、静态核查和整理，未生成合成 skill、未运行攻击、训练或测试实验，未安装或执行采集内容。

## 交付数量与计数口径

| 项目 | 数量 |
| --- | ---: |
| 原目录完整保留的 SKILL.md | 100 |
| 原样本精确去重后 | 100 |
| 原样本按本报告近似规则保留的代表 | 85 |
| 有效新增正文（samples/；manifest.csv） | 415 |
| 合并去重索引（combined_manifest.csv / combined_dataset.jsonl） | 500 |
| 原目录文件数 + 新增文件数 | 515 |
| 合并索引 family 数 | 416 |

**500 是本次明确规则下的正文样本数，不是 500 个相互独立的作者、来源或模板家族。** 原有 100 个文件全部未改动；其中 15 个只在合并索引中被其近似代表替代，映射见 `original_manifest.csv` 和 `excluded_samples.csv`。原有样本按共同模板保守归入同一个 family，因此合并后的 500 条对应 416 个 family。后续不能把这个原有模板家族拆到训练／测试两侧。

## 原数据定义与接入

原路径为 `../webapp/`。一个编号目录下的一份完整 UTF-8 `SKILL.md` 就是一条样本；正文含 YAML 风格头部（name、description、license）、Markdown 指南、流程和代码示例。100 条均为英文，长度为 2326–2695 个 Unicode 字符，主题均为 Python Playwright 网页测试；不同测试场景共用大量 operating principles、代码骨架和检查清单。原文件声明引用 LICENSE.txt，但原目录没有对应许可文件，其许可和原发布来源保持 `unknown`。

核对了项目 `util/data.py`：`Samples` 用 `Path(data_dir).rglob("SKILL.md")` 读取完整 UTF-8 文本；`WebTesting` 硬编码 `data/webapp`，随机种子硬编码为 0，按文件随机进行 80/20 划分。新增样本保持同样文件结构，字节不改写、不删前言、不截断、不补写。

- 只接入新增文本：将 `Samples` 的 `data_dir` 指向 `data/skill_expansion_20260921/samples`。`WebTesting` 不会自动发现新增目录。
- 接入完整去重后的 500 条：使用 `combined_dataset.jsonl`（每行含 content 和 family_id），或在项目根目录执行下面的**纯数据整理**命令，再把 `Samples.data_dir` 指向输出目录。此命令只复制数据，不运行任何实验。

```bash
python3 data/skill_expansion_20260921/tools/materialize_combined.py data/skills_combined_500
```

现有加载器不会读取 family_id；未来做训练／测试划分时仍需另行实现按 family 分组的拆分，并把 seed 参数化。本轮未修改实验代码、未生成任何训练／测试划分。不要把整个扩充目录作为 rglob 输入，应只用 samples/ 或 materialize 输出的单一目录。

## 检索范围与实际采集

检索了公开 GitHub skill 集合、维护者仓库、厂商仓库和专业领域仓库。入口关键词及已访问入口见 `search_log.json`；发现集合中的上游归属线索后继续追溯，例如从 antfu 集合追溯 Vue 社区上游，从 K-Dense 旧仓库名解析到新仓库。所有计入样本均实际下载并读取完整正文，未凭搜索摘要或目录名称计数。

共探查 27 个仓库入口，成功读取 25 个固定 commit 的文件集合，发现 1886 份候选 SKILL.md。通过结构检查 1858 份，再进行去重、家族约束、许可核查和来源／类别／长度平衡，最终从 22 个仓库入选 415 份。单仓库上限设置为 40；实际最高 29 份，占 7.0%。按仓库轮转，优先当时较少的功能类别和长度档，稳定哈希打破平局；没有使用模型响应、攻击成功率或预期攻击效果作为筛选依据。

无法访问的入口未计入样本：n8n-io/n8n-skills：HTTP Error 404: Not Found；tencent-connect/openclaw-docs：HTTP Error 404: Not Found。初始 Git 访问还受到本机失效代理影响，改用 GitHub HTTPS API 后成功。K-Dense 全仓库包超过 180 MB 上限，改为固定 commit 的完整 Git tree + 原始 SKILL.md/许可文件，下载的原始 blob 与 tree 中 SHA-1 一一校验，166 份正文均获取成功。

每份样本记录 commit、原始 blob URL、仓库路径、采集时间、SHA-256 和本地路径。优先保留维护者来源；`original_url` 指核实过的发布文件 URL，**不保证是互联网上最早发表的版本**。文中或头部明确的上游 URL 另列 `declared_upstream_urls`；不能确认的第一作者、原始许可等不推测。

## 正文与质量核查

所有候选都经过完整字节读取和 UTF-8 解码，校验 name/description 头部、正文至少 500 字符且至少 70 个词形片段、去掉链接与代码后的最低指南信息量，并排除测试夹具、示例模板、空壳和目录索引。为避免只收集链接页，进一步检查链接／表格以外的指南内容；结合正文抽查剔除了 Remotion 路由页、Turso 索引和部分 Vue 引用索引等。

这是一轮**自动全文静态检查 + 模型正文抽查**，不是 415 份逐条人工功能验收。本轮全文抽查日志见 `manual_reviews.json`，其中与最终入选集匹配的 22 份具有全文模型阅读记录；抽查以跨来源、短文本和目录风险为主，不保证内容的专业准确性。所有入选正文的传输和本地完整性均已校验；没有执行正文指令来测试其效果。

## 去重与 family 规则

1. 对原始字节计算 SHA-256；另外按 Unicode NFKC、小写、词字符归一化计算哈希。
2. 对去掉头部的完整正文生成 3 词和 5 词 shingle。全候选使用 64 维 MinHash、32 个两维 LSH band、固定种子 20260921 召回候选对，并加入同名、规范化名称和全部原样本对。
3. 重复条件为：精确／归一哈希相同，或 5-shingle Jaccard ≥ 0.80，或 3-shingle Jaccard ≥ 0.85，或较短文本的 5-shingle 包含率 ≥ 0.92 且长度比例 ≥ 0.60。同一 declared name 也保守合并，不把不同仓库同名版本直接算新增。
4. family 条件比删除规则宽：Jaccard ≥ 0.55，或包含率 ≥ 0.80 且长度比例 ≥ 0.50，或明确的同名、语言／SDK／版本后缀与场景变体规范化。对 Linux 发行版 triage 和相近 GitHub issue 创建模板额外归族；原有网页测试模板整体归族。每个新增 family 最多入选一个代表。
5. 使用连通分量合并 family／重复组，保留原数据代表和优先来源代表。边、相似度、原因保存在 `similarity_pairs.csv`，未入选记录在 `excluded_samples.csv`。被容量／分布规则留作储备的候选不等于无效或重复。
6. 入选后额外逐对精确计算新增—新增及新增—全部原样本的相似度，共 127,405 对；未发现漏归族的阈值命中对，结果见 `validation.json` 与 `final_similarity_audit.csv`。因此最终集合的这部分验证不依赖 LSH 召回率。

这些规则可能保守合并名称相同但独立编写的内容，连通分量也可能扩大分组；反之，跨语言翻译、重写幅度大的同源内容仍可能漏检。没有调用外部 embedding 或翻译模型进行语义判定，不宣称排除了所有语义同源。语言／版本／原作者线索用于额外归族，而不是把翻译计作独立样本。

## 新增样本分布

### 来源

| 仓库 | 数量 | 占新增比例 |
| --- | ---: | ---: |
| [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 29 | 7.0% |
| [alirezarezvani/claude-skills](https://github.com/alirezarezvani/claude-skills) | 29 | 7.0% |
| [antfu/skills](https://github.com/antfu/skills) | 15 | 3.6% |
| [anthropics/skills](https://github.com/anthropics/skills) | 14 | 3.4% |
| [benjitaylor/agentation](https://github.com/benjitaylor/agentation) | 2 | 0.5% |
| [cloudflare/skills](https://github.com/cloudflare/skills) | 13 | 3.1% |
| [coreyhaines31/marketingskills](https://github.com/coreyhaines31/marketingskills) | 29 | 7.0% |
| [expo/skills](https://github.com/expo/skills) | 26 | 6.3% |
| [getsentry/skills](https://github.com/getsentry/skills) | 25 | 6.0% |
| [github/awesome-copilot](https://github.com/github/awesome-copilot) | 29 | 7.0% |
| [huggingface/skills](https://github.com/huggingface/skills) | 26 | 6.3% |
| [microsoft/skills](https://github.com/microsoft/skills) | 29 | 7.0% |
| [obra/superpowers](https://github.com/obra/superpowers) | 15 | 3.6% |
| [openai/skills](https://github.com/openai/skills) | 28 | 6.7% |
| [phuryn/pm-skills](https://github.com/phuryn/pm-skills) | 29 | 7.0% |
| [resend/resend-skills](https://github.com/resend/resend-skills) | 4 | 1.0% |
| [stripe/ai](https://github.com/stripe/ai) | 10 | 2.4% |
| [supabase/agent-skills](https://github.com/supabase/agent-skills) | 1 | 0.2% |
| [trailofbits/skills](https://github.com/trailofbits/skills) | 28 | 6.7% |
| [vercel-labs/agent-skills](https://github.com/vercel-labs/agent-skills) | 4 | 1.0% |
| [vuejs-ai/skills](https://github.com/vuejs-ai/skills) | 2 | 0.5% |
| [wshobson/agents](https://github.com/wshobson/agents) | 28 | 6.7% |

### 功能类别

| 类别 | 数量 | 占新增比例 |
| --- | ---: | ---: |
| cloud | 35 | 8.4% |
| content_creation | 36 | 8.7% |
| data_analysis | 35 | 8.4% |
| documents | 16 | 3.9% |
| information_retrieval | 34 | 8.2% |
| marketing | 35 | 8.4% |
| product_management | 34 | 8.2% |
| scientific_research | 25 | 6.0% |
| security | 37 | 8.9% |
| software_development | 91 | 21.9% |
| workflow | 37 | 8.9% |

分类为单一主类别，由名称、路径和来源规则赋值；一个 skill 可能覆盖多个功能，类别不是人工金标准。

### 正文长度与语言

| Unicode 字符档 | 数量 | 占新增比例 |
| --- | ---: | ---: |
| 15000+ | 115 | 27.7% |
| 2000-4999 | 115 | 27.7% |
| 5000-14999 | 164 | 39.5% |
| <2000 | 21 | 5.1% |

全文长度范围 650–86,173 字符，中位数 8,083 字符。字符数包括头部、空白、代码与换行；另提供 UTF-8 字节数、词形片段数和行数。**没有将词数冒充 token 数**，不同模型的 prefix_length/tokenizer 适用性需后续单独核对。最长样本为 `claude-api`，没有为了长度分布而截断。

语言标签为英文 415 份，原数据也是英文。语言通过字符分布启发式确认并经抽查；本轮没有形成多语言平衡语料。

## 许可、依赖与待核查项

| 许可信息 | 新增数量 | 占新增比例 |
| --- | ---: | ---: |
| Apache-2.0 | 100 | 24.1% |
| CC-BY-SA-4.0 | 29 | 7.0% |
| MIT | 286 | 68.9% |

优先检查 skill 邻近许可文件，再查父目录／仓库许可；无许可文件时仅在头部明确给出标准许可标识时使用该声明。头部明确 unknown、声明冲突或自定义条款未确认适用范围的条目不进入有效新增集；原始声明保存在 license_declared，证据路径保存在 license_evidence。许可识别是文档证据整理，不是法律意见；CC-BY-SA 与 MIT／Apache 的义务不同，不能给整个数据包重新统一标注 MIT。

`pending_review.csv` 共 87 个结构合格但许可未知／自定义／冲突的候选，其中 81 个是去重后因许可待核查而未入选的代表。部分文档 skill 的条款明确限制复制，部分 Figma skill 适用专有开发者条款；未将这些正文放入 samples/。未知来源或许可没有自行补造。原始 100 条的许可仍是 unknown。

每个入选样本都有 `dependencies/<sample_id>.json`：包含固定 commit 下同目录附属文件的完整路径清单、头部 compatibility/allowed-tools 等字段、依赖相关原文行、外链、Markdown 相对路径是否存在于仓库快照。共 315 个样本在源目录有附属文件，21 个样本存在未解析到仓库文件的相对链接；这些也可能是示例路径、运行时输出或跨技能引用，不能一概认定损坏。动态路径、反引号路径与环境依赖可能漏提取。

**415 份均可作为原实验的完整文本输入；没有一份被认证为可独立运行的完整工具包。** 附属脚本、环境、CLI、模型、服务账号和凭证均未执行／安装／验证。依赖缺口不影响当前只读取正文的实验，但如果未来改为执行 skill，必须另行准备并核查。为避免把候选／受限正文和整仓库资产混入交付，最终 sources 中的压缩包仅保留入选正文及许可证据，附属文件只交付清单。原下载包哈希与固定 commit 仍保留在 inventory 中，可追溯重取。

## 覆盖局限与验证结果

- 全部来自 GitHub 的公开发布或维护者集合，受检索可见度与入选仓库影响，不是全生态随机样本；同一公司的多个库、同一作者模板及外部知识源仍可能相关。
- 比原来的单一网页测试领域更广；因此加入这些数据会改变任务领域分布，不能把变化全部解释为样本量效应。
- 每来源设上限且新增 family 只留一个代表，但相似度阈值不等价于真实统计独立性，尤其原有网页模板是一个大 family。
- 保留真实发布的 skill，包括维护者注明由文档生成的公开 skill；本轮自己没有生成或改写任何 skill，亦不声称所有公开文件均由人逐字编写。
- 上游服务、API 和正文中的版本说明可能过时。commit 冻结保证本次文本可追溯，不保证执行效果。
- 验证结果：PASS；515 份原／新增正文哈希一致，100 份原文件未改动，415 个新增目录与 manifest 一一对应，127,405 对最终相似度复核无漏归族命中。验证只针对数据完整性、结构和声明的去重规则。

## 文件索引与复现

| 文件 | 用途 |
| --- | --- |
| samples/ | 415 份有效新增原始正文，每个目录一份 SKILL.md |
| manifest.csv | 新增信息、来源／commit／许可／长度／哈希／family／依赖／本地路径 |
| combined_manifest.csv | 原 85 代表 + 新 415 的合并去重索引，路径相对此目录 |
| combined_dataset.jsonl | 可移植的 500 条完整文本与 family 字段 |
| original_manifest.csv / original_hashes.json | 原 100 条审计、保留代表和不可变哈希 |
| candidate_manifest.csv | 全部结构合格候选元数据（包含原样本）；不代表全部入选 |
| excluded_samples.csv / pending_review.csv | 未选／剔除原因、重复代表和待核查条目 |
| similarity_pairs.csv / final_similarity_audit.csv / family_groups.csv | 去重边、最终逐对检查和分组 |
| dependencies/ / dependency_summary.csv | 附属文件与依赖证据，未执行 |
| sources.csv / source_index.json / sources/ | 仓库版本、文件树、许可证据与精选正文快照 |
| manual_reviews.json / validation.json / summary.json | 抽查记录、验证结果和机器可读统计 |
| tools/ | 自编采集、去重、验证、报告和纯数据物化脚本；不是下载的 skill 脚本 |

CSV 为 UTF-8 BOM，正文原始 UTF-8 字节保留。全量离线候选正文不随精选包交付；要重新跑全候选去重，应先用 collect.py 重新取得 inventory 记录的固定 commit（其缓存复取逻辑不漂移到 HEAD），科研仓库用 collect_scientific.py，再依次执行 curate.py、validate.py、package_data.py、write_report.py。离线检查现有交付仅需 validate.py（Python 3 + NumPy）。若只需读数据，不需要安装采集脚本依赖。
