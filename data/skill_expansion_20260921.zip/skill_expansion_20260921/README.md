# 从这里查看具体 Skill

新增的 415 个 skill 正文都在 **samples/** 中。现在采用「功能类别 / 编号_名称 / SKILL.md」结构，打开 SKILL.md 就能看完整原文。

原来的 100 个网页测试样本仍在 `../webapp/`，没有移动。新增数据涵盖多种任务，因此分为以下 11 类。

| 功能类别文件夹 | 数量 |
| --- | ---: |
| [01_文档处理](samples/01_文档处理/) | 16 |
| [02_数据分析](samples/02_数据分析/) | 35 |
| [03_软件开发](samples/03_软件开发/) | 91 |
| [04_信息检索](samples/04_信息检索/) | 34 |
| [05_工作流与协作](samples/05_工作流与协作/) | 37 |
| [06_内容创作](samples/06_内容创作/) | 36 |
| [07_科学研究](samples/07_科学研究/) | 25 |
| [08_安全与审计](samples/08_安全与审计/) | 37 |
| [09_云服务与部署](samples/09_云服务与部署/) | 35 |
| [10_市场营销](samples/10_市场营销/) | 35 |
| [11_产品管理](samples/11_产品管理/) | 34 |

## 示例

```text
samples/
  01_文档处理/
    001_azure-ai-document-intelligence-dotnet/
      SKILL.md
  02_数据分析/
    017_analytics/
      SKILL.md
  03_软件开发/
    052_agentation/
      SKILL.md
```

## 其他文件有什么用

- `manifest.csv`：415 个新增 skill 的目录、名称、类别、来源和许可。`local_path` 就是正文位置。
- `combined_dataset.jsonl`：原数据代表与新增数据合并后的 500 条完整文本，供程序读取。
- `collection_report.md`：采集数量、去重方法和局限。
- `sources/`、`dependencies/` 和其他 CSV/JSON：来源、依赖和去重核查记录；看正文不需要翻这些文件。

目录中的数字仅用于方便浏览，稳定标识仍是 manifest.csv 的 sample_id。重命名只调整目录，正文和哈希未改变。
现有 Samples 加载器会递归查找 SKILL.md，因此增加类别目录后仍然可读取 samples/。

这里的 skill 指令是实验数据，本轮没有执行它们。
